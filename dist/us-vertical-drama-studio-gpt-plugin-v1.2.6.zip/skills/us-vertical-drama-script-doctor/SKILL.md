---
name: us-vertical-drama-script-doctor
description: Independently score a US vertical-drama screenplay against its approved beat sheet and issue a binding PASS, REWRITE, or REJECT gate.
---
# Script Doctor

For a new project, use `usvd-v10-controller` for story diagnosis and review before production. This legacy skill may review a supplied script or a documented legacy project, but a `PASS` here cannot approve the V10 Story Package or bypass its trusted human gate.

## Trigger and scope

Use after Screenwriter submits a draft with its APPROVED Beat Sheet, Story Bible, and continuity ledger. Assess independently; do not become the writer of record.

## Non-goals

Do not silently rewrite pages, replace the beat sheet, waive mandatory failures, or produce storyboards.

## Inputs

Required: Screenplay Draft, APPROVED Beat Sheet, APPROVED Story Bible, and current continuity ledger. Optional: prior doctor notes and production constraints.

## Workflow

1. Confirm the handoff packet is complete and trace every core beat into the draft.
2. Score with `references/script-doctor-rubric.md` for 100 points.
3. Check mandatory-fail conditions before applying numeric score, then complete a scene-ID and dialogue-function audit. Use `references/native-dialogue-guide.md` to assess the target locale, period, class/profession register, character voice, and translationese risk.
4. Issue a precise PASS, REWRITE, or REJECT report with actionable notes by beat/page/scene.

## Hard rules

- This role is independent from writing. Diagnose; do not covertly author a replacement.
- Default gate: >=85 PASS; 75-84 REWRITE; <75 REJECT.
- Mandatory-fail conditions override numeric score: missing required handoff artifact; unapproved core-beat redesign; EP01 missing or materially weak Hook, Conflict, Escalation, Reversal, Payoff, or Cliffhanger; material canon/continuity break; no comprehensible early objective/obstacle in EP01; absent local payoff; or absent concrete next-episode question.
- Check the bilingual script standard: each creator-facing scene/action/performance/production field has paired Chinese and natural English; each spoken line uses `ENGLISH CHARACTER NAME: “English dialogue.”` with adjacent Chinese reference meaning marked unspoken and excluded from lip-sync. Require a separate `【OS／画外音】` field per scene; check English performed OS plus Chinese reference when present, or `无／None` when absent. Never count unspoken `【情绪/表演】` as OS. Flag missing or meaning-divergent pairs.
- Mandatory check for screenplay annotations: every scene must retain a scene ID and label `【场景】`, `【人物】`, `【动作】`, `【情绪/内心】`, and `【台词】`; reject unlabelled prose as storyboard-ready. Reject an emotion/intent direction that has no observable performance evidence. Complete a dialogue-function audit: check that each spoken line changes or pressures emotion, relationship, information, or action.
- For US-facing dialogue, record the target locale/world, period, social register, and character voice evidence. Flag translationese, false-local idiom, or an unsupported regional/class claim; natural English alone is not sufficient evidence of localization.
- A non-PASS script must not hand off to storyboard.

## Output contract

Return `Script Doctor Gate: PASS|REWRITE|REJECT`, 100-point category scorecard, mandatory-fail result, evidence, required rewrite targets, and a storyboard authorization only for PASS.

## Handoff contract

PASS goes to Continuity Editor, then `us-vertical-drama-storyboard-director`. REWRITE goes to Screenwriter with the same locked beat sheet unless upstream approval changes it. REJECT goes to Showrunner/Episode Architect for structural repair. A non-PASS script must not hand off to storyboard.

## Failure and rewrite conditions

REWRITE when score is 75-84 without a mandatory fail. REJECT when score is <75 or a mandatory fail exposes a structural/canon failure. EP01 retention-structure failures return REWRITE when the approved series architecture remains valid, and REJECT when the defect requires changing the Story Bible or approved episode architecture. Do not issue PASS until all mandatory-fail conditions are clear.
