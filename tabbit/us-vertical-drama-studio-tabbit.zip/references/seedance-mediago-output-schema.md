# Seedance / MediaGo Shot Output Schema

Emit two linked records: one direct-generation record per `VIDEO-*`, followed by one local-adjustment record per child `SHOT-*`. Keep the same `scene_id`, IDs, and approved asset IDs in the screenplay, prompt map, and import output. Emit a Markdown table for review; additionally emit JSON or CSV only when the selected MediaGo build specifies an accepted import format.

| Field | Required | Meaning |
|---|---:|---|
| `video_prompt_id`, `video_master_prompt`, `video_negative_prompt` | yes on every VIDEO record | Chinese direct-submission prompt for the full video package, including time sequence/cuts, locked assets, camera, light, sound/voice plan, continuity and exclusions. This is not replaced by child SHOT prompts. |
| `scene_id`, `video_id`, `shot_id`, `prompt_id` | yes | Stable source, video package, time-coded micro-shot, and prompt-placement IDs. Supply Chinese display names beside each human-visible ID. |
| `display_name_zh`, `shot_type` | yes | Chinese operator-facing name and Chinese shot type such as `反应`, `特写插入`, `动作`, or `对白`. |
| `timeline_in_seconds`, `timeline_out_seconds`, `duration_seconds` | yes | Exact placement inside its parent video package and planned micro-shot duration. The ranges are contiguous; a normal micro-shot runs 0.5–3 seconds. |
| `target_model` | yes | Selected target, e.g. `Seedance 2.0`; never assume a capability. |
| `character_reference_ids`, `look_reference_ids`, `scene_reference_id`, `prop_reference_ids` | yes when applicable | Approved `CHAR/LOOK/SET/PROP` IDs and approved image/reference paths. |
| `asset_lock_prompt`, `shot_delta_prompt`, `negative_prompt` | yes | Chinese production prompts: immutable approved asset anchors, the micro-shot-specific change, and exclusions. Embedded approved English character names and spoken lines remain English. |
| `camera`, `continuity_in`, `continuity_out` | yes | Composition/movement plus inter-shot state and screen-direction continuity. |
| `source_coverage`, `asset_state_in`, `asset_state_out` | yes | Source unit mapping plus machine-checkable wardrobe, prop, set, weather/light, and damage state. |
| `dialogue_audio`, `lip_sync_timing` | required when dialogue is spoken | Exact approved English line(s), speaker, and start/end seconds; otherwise `none`. |
| `voice_cues` | yes | Dialogue/voice, ambience, SFX, and music cues with time range and execution responsibility; mark unsupported model features as external. |
| `start_frame_reference`, `end_frame_reference`, `seed`, `duration_exception_reason_zh`, `short_duration_reason_zh` | optional / conditional | Supply only when supported and selected. An exception reason is required outside the normal 0.5–3 second micro-shot range. |
| `export_row`, `generation_status`, `generation_result_id` | yes / pending / optional | Stable row ID, `pending` until generated, and a returned result ID only after the target system provides one. |

## Seedance use

Treat `target_model: Seedance 2.0` as a target label, not proof of a specific duration, reference-image, seed, frame-control, or audio feature. Obtain those limits from the user’s enabled endpoint or current MediaGo adapter; validate against them before export.

## MediaGo handoff

MediaGo receives the Asset Creation Pack first, then approved reference IDs/paths, followed by one direct VIDEO record and its time-coded micro-shot records. If MediaGo has no structured-import adapter, return the same fields as a Chinese review table and preserve the prompt-placement map; do not pretend a generic JSON blob can be imported. The native adapter must map `VIDEO-*`, `VIDEO-PROMPT-*`, `SHOT-*`, `PROMPT-*`, asset IDs, and `export_row` without flattening them away.
